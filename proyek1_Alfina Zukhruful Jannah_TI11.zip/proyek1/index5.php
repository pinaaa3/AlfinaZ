<?php
include_once 'header.php';
include_once 'sidebar.php';
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Praktikum</h1>
          </div>
          <div class="col-sm-6">
            <olFixed Layout< class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Layout</a></li>
              <li class="breadcrumb-item active">Fixed Layout</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Praktikum 5</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
              <?php
              class Dispenser{
                protected $volume;
                protected $hargaSegelas;
                private $volumeGelas;
                public $namaMinuman;

                function  volume($vol){
                  $this->volume = $vol;
                }
              }

              class Minuman extends Dispenser
              {
                public $uang;
                function __construct($uang, $namaMinuman, $volumeGelas, $harga)
                {
                  $this->uang = $uang;
                  $this->namaMinuman = $namaMinuman;
                  $this->hargaSegelas = $harga;
                  $this->volumeGelas = $volumeGelas;
                }

                function transaksi($uang)
                {
                  $this->uang = $uang;
                  return  $this->uang - $this->hargaSegelas;
                }

                function volumeSetelahdibeli()
                {
                  $this->volume = $this->volume - $this->volumeGelas;
                  return $this->volume;
                }

                function cetak()
                {
                  echo '<h1>'. 'Welcome To this Menu '.'</h1>';
                  echo '<hr>';
                  echo 'Nama Minuman : ' . $this->namaMinuman . "<br>";
                  echo 'Uang Saat ini : ' . $this->uang . "<br>";
                  echo 'Kapasistas (volume) Dispenser : ' . $this->volume . 'ml' . "<br>";
                  echo 'Harga Bayar Segelas Minuman : ' . $this->hargaSegelas . "<br>";
                  echo 'Volume Dispenser Setelah Dibeli : ' . $this->volumeSetelahDibeli() . 'ml' . "<br>";
                  echo 'Sisa Uang: ' . $this->transaksi($this->uang);
                  echo '<hr>';
                  echo '<br>';
                  echo '<h3>'. 'Thanks For Dropping '.'</h3>';
                }
              }

              $minuman = new Minuman(10000, 'Aqua', 4000, 6000);
              $minuman->transaksi($minuman->uang);
              $minuman->volume(8000);
              $minuman->cetak();
              ?>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
              </div>
              <!-- /.card-footer-->
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php
include_once 'footer.php';
?>