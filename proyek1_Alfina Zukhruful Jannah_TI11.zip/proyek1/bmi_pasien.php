<?php
include_once 'header.php';
include_once 'sidebar.php';
require_once "BMI.php";
error_reporting(0);
$pasien = array(
    1 => array(1, "2022-01-10", "P001", "Ahmad", "Pria", 69.8, 169, 24.7, "Kelebihan Berat Badan"),
        array(2, "2022-01-10", "P002", "Rina", "Wanita", 55.3, 165, 20.3, "Sehat (Ideal)"),
        array(3, "2022-01-11", "P003", "Luthfi", "Pria", 45.2, 171, 15.4, "Kekurangan Berat Badan")
    );

$nama = $_POST['name'];
$tmpt_lahir = $_POST['location'];
$jenis_kelamin = $_POST['gender'];
$tgl_lahir = $_POST['tanggalLahir'];
$berat_badan = $_POST['weight'];
$tinggi_badan = $_POST['height'];
$email = $_POST['email'];

$psn_baru = new BmiPasien(count($pasien) + 1, $tanggal, $nama, $tmpt_lahir, $tgl_lahir, $jenis_kelamin, $email, $berat_badan, $tinggi_badan);
$psn_baru->bmi = $psn_baru->hasilBMI();
array_push($pasien, array(
$psn_baru->id, 
$psn_baru->tanggal, 
$psn_baru->kode, 
$psn_baru->nama, 
$psn_baru->jenis_kelamin, 
$psn_baru->berat_badan,
$psn_baru->tinggi_badan, 
$psn_baru->bmi, 
$psn_baru->nilai($psn_baru->bmi)));
?>

<div class="content-wrapper">
          <!-- Content Header (Page header) -->
          <div class="content-header">
            <div class="container-fluid">
              <div class="row mb-2">
                <div class="col-sm-6">
                  <h1 class="m-0">Data Pasien BMI</h1>
                </div>
                <!-- /.col -->
                <div class="col-xl-6 col-sm-10 col-12">
                  <div class="form-group row">
                    <div class="col-sm-3">
                      <div class="form-check mt-2">
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check mt-2">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-8 icon-header-colom">
                 <a href="content.php"><i class="bi bi-calendar-plus icon-header"></i></a> 
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
          </div>
  
          <!-- /.content-header -->
          <!-- Main content -->
          <div class="content">
            <div class="container-fluid">
              <div class="row">
                <div class="col">
                  <!-- /.card -->
                  <table class="table table-striped table-bordered">
                  <thead class="table-dark">
                        </div>
                            <tr>
                                <th>No</th>
                                <th>Tanggal Periksa</th>
                                <th>Kode Pasien</th>
                                <th>Nama Pasien</th>
                                <th>Gender</th>
                                <th>Berat Badan (Kg)</th>
                                <th>Tinggi Badan (Cm)</th>
                                <th>Nilai BMI</th>
                                <th>Status BMI</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                foreach($pasien as $obj => $val){
                                    echo "<tr>";
                                        echo "<td>".$val[0]."</td>";
                                        echo "<td>".$val[1]."</td>";
                                        echo "<td>".$val[2]."</td>";
                                        echo "<td>".$val[3]."</td>";
                                        echo "<td>".$val[4]."</td>";
                                        echo "<td>".$val[5]."</td>";
                                        echo "<td>".$val[6]."</td>";
                                        echo "<td>".$val[7]."</td>";
                                        echo "<td>".$val[8]."</td>";
                                    echo "</tr>";
                                }
                            ?>
                        </tbody>
                   
                  </table>
  
                  <!-- /.card -->
                </div>
                <!-- /.col-md-6 -->
  
                <!-- /.col-md-6 -->
              </div>
              <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
          </div>
          <!-- /.content -->
        </div>
        <!-- /.content-wrapper --
<?php 
    include_once 'footer.php';
?>